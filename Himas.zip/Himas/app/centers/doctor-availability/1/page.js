'use client';

import React, { useState, useEffect } from 'react';

const ManageDoctorAvailability = ({ currentClinic }) => {
  const [doctors, setDoctors] = useState([]);
  const [availability, setAvailability] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [selectedDate, setSelectedDate] = useState(''); // New state for selected date
  const [filteredDoctors, setFilteredDoctors] = useState([]);
  const [newDoctor, setNewDoctor] = useState({ name: '', specialty: '' });
  const [editAvailability, setEditAvailability] = useState(null); // Handle editing availability
  const [newAvailability, setNewAvailability] = useState({
    doctorId: '',
    dates: [], // Array of dates for multiple appointments
    time: '',
    status: 'available'
  });

  // State for current clinic
  const [clinic, setClinic] = useState(currentClinic);

  useEffect(() => {
    if (!clinic) {
      // Add some sample clinic data if currentClinic is not passed
      const sampleClinic = {
        name: 'Downtown Medical Center',
        id: 1,
      };
      setClinic(sampleClinic); // Setting clinic data here
    }

    const fetchData = async () => {
      const sampleDoctors = [
        { id: 1, name: 'Dr. John Doe', specialty: 'Cardiology' },
        { id: 2, name: 'Dr. Jane Smith', specialty: 'Pediatrics' },
        { id: 3, name: 'Dr. Emily Johnson', specialty: 'Dermatology' },
      ];

      const sampleAvailability = [
        { id: 1, doctorId: 1, date: '2025-03-28', time: '08:00 AM - 12:00 PM', status: 'available' },
        { id: 2, doctorId: 1, date: '2025-03-29', time: '02:00 PM - 06:00 PM', status: 'unavailable' },
        { id: 3, doctorId: 2, date: '2025-03-30', time: '09:00 AM - 01:00 PM', status: 'on hold' },
        { id: 4, doctorId: 3, date: '2025-03-31', time: '10:00 AM - 02:00 PM', status: 'available' },
      ];

      setDoctors(sampleDoctors);
      setAvailability(sampleAvailability);
    };

    fetchData();
  }, [clinic]);

  useEffect(() => {
    const filtered = doctors.filter((doctor) =>
      doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      (selectedSpecialty ? doctor.specialty === selectedSpecialty : true)
    );
    setFilteredDoctors(filtered);
  }, [searchQuery, selectedSpecialty, doctors]);

  const handleStatusColor = (status) => {
    switch (status) {
      case 'available':
        return '#28a745'; // Green
      case 'unavailable':
        return '#dc3545'; // Red
      case 'on hold':
        return '#007bff'; // Blue
      default:
        return '#6c757d'; // Grey
    }
  };

  // Handle adding new availability for multiple dates
  const handleAddAvailability = (e) => {
    e.preventDefault();

    const newEntries = newAvailability.dates.map((date, idx) => ({
      id: availability.length + idx + 1,
      doctorId: parseInt(newAvailability.doctorId),
      date,
      time: newAvailability.time,
      status: newAvailability.status,
    }));

    setAvailability((prev) => [...prev, ...newEntries]);

    // Reset form
    setNewAvailability({
      doctorId: '',
      dates: [],
      time: '',
      status: 'available',
    });
  };

  // Handle editing availability for multiple dates
  const handleEditAvailability = (e) => {
    e.preventDefault();
    const updatedAvailability = availability.map((avail) =>
      avail.id === editAvailability.id
        ? { ...avail, ...editAvailability }
        : avail
    );
    setAvailability(updatedAvailability);
    setEditAvailability(null); // Close the edit form
  };

  // Add a new doctor and their availability
  const handleAddDoctor = (e) => {
    e.preventDefault();
    const newDoctorEntry = {
      ...newDoctor,
      id: doctors.length + 1,
    };
    setDoctors((prevDoctors) => [...prevDoctors, newDoctorEntry]);
    setNewDoctor({ name: '', specialty: '' }); // Reset doctor form
  };

  // Handle multiple date input for adding/editing availability
  const handleDateChange = (e) => {
    const { value } = e.target;
    setNewAvailability((prevAvailability) => ({
      ...prevAvailability,
      dates: value.split(',').map((date) => date.trim())
    }));
  };

  // Filter the availability by selected date
  const filterAvailabilityByDate = (doctorId) => {
    if (!selectedDate) return availability.filter((avail) => avail.doctorId === doctorId);
    return availability.filter((avail) => avail.doctorId === doctorId && avail.date === selectedDate);
  };

  return (
    <div style={styles.wrapper}>
      <h1 style={styles.header}>Manage Doctor Availability</h1>

      <div style={styles.searchFilterContainer}>
        <input
          type="text"
          placeholder="Search by doctor name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={styles.searchInput}
        />
        <select
          value={selectedSpecialty}
          onChange={(e) => setSelectedSpecialty(e.target.value)}
          style={styles.filterSelect}
        >
          <option value="">Filter by Specialty</option>
          <option value="Cardiology">Cardiology</option>
          <option value="Pediatrics">Pediatrics</option>
          <option value="Dermatology">Dermatology</option>
        </select>
      </div>

      <div style={styles.dateFilterContainer}>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          style={styles.dateInput}
        />
      </div>

      <div style={styles.dashboardOverview}>
        <p style={styles.statText}><strong>Total Doctors: </strong>{filteredDoctors.length}</p>
        <p style={styles.statText}><strong>Available Slots: </strong>{filteredDoctors.filter((doctor) => filterAvailabilityByDate(doctor.id).some((avail) => avail.status === 'available')).length}</p>
      </div>

      <div style={styles.grid}>
        {filteredDoctors.length > 0 ? (
          filteredDoctors.map((doctor) => (
            <div key={doctor.id} style={styles.card}>
              <div style={styles.doctorHeader}>
                <span role="img" aria-label="doctor" style={styles.icon}>👨‍⚕️</span>
                <div>
                  <h2 style={styles.name}>{doctor.name}</h2>
                  <p style={styles.specialty}>{doctor.specialty}</p>
                </div>
              </div>

              <div style={styles.availabilitySection}>
                <h3 style={styles.availTitle}>Availability</h3>
                {filterAvailabilityByDate(doctor.id).map((slot, idx) => (
                  <div key={idx} style={styles.slot}>
                    <p>
                      <strong>{slot.date}:</strong> {slot.time} -{' '}
                      <span style={{ color: handleStatusColor(slot.status), fontWeight: 'bold' }}>{slot.status}</span>
                      <button onClick={() => setEditAvailability(slot)} style={styles.editButton}>Edit</button>
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <p>No doctors available at the moment.</p>
        )}
      </div>

      <div style={styles.availabilityForm}>
        <h3 style={styles.availTitle}>Add New Doctor</h3>
        <form onSubmit={handleAddDoctor} style={styles.form}>
          <input
            type="text"
            placeholder="Doctor's Name"
            value={newDoctor.name}
            onChange={(e) => setNewDoctor({ ...newDoctor, name: e.target.value })}
            style={styles.input}
          />
          <select
            value={newDoctor.specialty}
            onChange={(e) => setNewDoctor({ ...newDoctor, specialty: e.target.value })}
            style={styles.input}
          >
            <option value="">Select Specialty</option>
            <option value="Cardiology">Cardiology</option>
            <option value="Pediatrics">Pediatrics</option>
            <option value="Dermatology">Dermatology</option>
          </select>
          <button type="submit" style={styles.button}>Add Doctor</button>
        </form>
      </div>

      {/* Add Availability for Multiple Dates */}
      <div style={styles.availabilityForm}>
        <h3 style={styles.availTitle}>Add Availability for Multiple Dates</h3>
        <form onSubmit={handleAddAvailability} style={styles.form}>
          <select
            value={newAvailability.doctorId}
            onChange={(e) =>
              setNewAvailability({ ...newAvailability, doctorId: e.target.value })
            }
            style={styles.input}
          >
            <option value="">Select Doctor</option>
            {doctors.map((doctor) => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.name}
              </option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Enter Dates (comma-separated)"
            value={newAvailability.dates.join(', ')}
            onChange={handleDateChange}
            style={styles.input}
          />
          <input
            type="text"
            placeholder="Time (e.g., 08:00 AM - 12:00 PM)"
            value={newAvailability.time}
            onChange={(e) =>
              setNewAvailability({ ...newAvailability, time: e.target.value })
            }
            style={styles.input}
          />
          <select
            value={newAvailability.status}
            onChange={(e) =>
              setNewAvailability({ ...newAvailability, status: e.target.value })
            }
            style={styles.input}
          >
            <option value="available">Available</option>
            <option value="unavailable">Unavailable</option>
            <option value="on hold">On Hold</option>
          </select>
          <button type="submit" style={styles.button}>Add Availability</button>
        </form>
      </div>

      {/* Edit Availability Form */}
      {editAvailability && (
        <div style={styles.availabilityForm}>
          <h3 style={styles.availTitle}>Edit Availability</h3>
          <form onSubmit={handleEditAvailability} style={styles.form}>
            <select
              value={editAvailability.doctorId}
              onChange={(e) =>
                setEditAvailability({ ...editAvailability, doctorId: e.target.value })
              }
              style={styles.input}
            >
              <option value="">Select Doctor</option>
              {doctors.map((doctor) => (
                <option key={doctor.id} value={doctor.id}>
                  {doctor.name}
                </option>
              ))}
            </select>
            <input
              type="date"
              value={editAvailability.date}
              onChange={(e) =>
                setEditAvailability({ ...editAvailability, date: e.target.value })
              }
              style={styles.input}
            />
            <input
              type="text"
              placeholder="Time (e.g., 08:00 AM - 12:00 PM)"
              value={editAvailability.time}
              onChange={(e) =>
                setEditAvailability({ ...editAvailability, time: e.target.value })
              }
              style={styles.input}
            />
            <select
              value={editAvailability.status}
              onChange={(e) =>
                setEditAvailability({ ...editAvailability, status: e.target.value })
              }
              style={styles.input}
            >
              <option value="available">Available</option>
              <option value="unavailable">Unavailable</option>
              <option value="on hold">On Hold</option>
            </select>
            <button type="submit" style={styles.button}>Update Availability</button>
          </form>
        </div>
      )}

    </div>
  );
};

const styles = {
  wrapper: {
    padding: '20px',
    backgroundColor: '#ffffff',
    minHeight: '100vh',
    fontFamily: 'Segoe UI, sans-serif',
  },
  header: {
    textAlign: 'center',
    color: '#2c3e50',
    fontSize: '2.2rem',
    marginBottom: '20px',
    fontWeight: 'bold',
  },
  searchFilterContainer: {
    display: 'flex',
    gap: '15px',
    justifyContent: 'center',
    marginBottom: '20px',
  },
  searchInput: {
    padding: '10px',
    width: '250px',
    fontSize: '1rem',
    fontWeight: 'bold',
    backgroundColor: '#4F959D',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  dateFilterContainer: {
    textAlign: 'center',
    marginBottom: '20px',
  },
  dateInput: {
    padding: '10px',
    fontSize: '1rem',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#ffffff',
    color: '#007bff',  // Change text color for the date input to blue (visible)
    fontWeight: 'bold',
  },
  filterSelect: {
    padding: '10px',
    fontSize: '1rem',
    fontWeight: 'bold',
    backgroundColor: '#4F959D',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
  },
  dashboardOverview: {
    textAlign: 'center',
    marginBottom: '30px',
  },
  statText: {
    fontSize: '1.2rem',
    color: '#34495e',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
    gap: '25px',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: '15px',
    padding: '20px',
    boxShadow: '0 8px 15px rgba(0,0,0,0.1)',
    transition: 'transform 0.2s',
  },
  doctorHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '15px',
    marginBottom: '15px',
  },
  icon: {
    fontSize: '40px',
  },
  name: {
    margin: 0,
    fontSize: '1.4rem',
    color: '#34495e',
    fontWeight: 'bold',
  },
  specialty: {
    margin: 0,
    color: '#7f8c8d',
    fontSize: '1rem',
  },
  availabilitySection: {
    marginTop: '10px',
  },
  availTitle: {
    color: '#2980b9',
    fontSize: '1.1rem',
    marginBottom: '8px',
    fontWeight: 'bold',
  },
  slot: {
    margin: '4px 0',
    fontSize: '1rem',
    color: '#555',
  },
  editButton: {
    marginLeft: '10px',
    padding: '5px 10px',
    backgroundColor: '#ffb81c',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    color: '#fff',
  },
  availabilityForm: {
    marginTop: '30px',
    padding: '15px',
    backgroundColor: '#f4f6f7',
    borderRadius: '8px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    maxWidth: '500px',
    margin: '0 auto',
  },
  input: {
    padding: '10px',
    fontSize: '1rem',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
  },
  button: {
    padding: '10px',
    backgroundColor: '#007bff',
    color: '#fff',
    fontSize: '1rem',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
};

export default ManageDoctorAvailability;
