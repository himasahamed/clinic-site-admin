'use client';

import React, { useState, useEffect } from 'react';

const ClinicalCenterDashboard = () => {
  const [centers, setCenters] = useState([]);
  const [currentClinic, setCurrentClinic] = useState(null); // Track the logged-in clinic center

  // Simulating a clinic center login with hardcoded data
  useEffect(() => {
    // Here, you would typically fetch the logged-in clinic data from a server or local storage.
    const loggedInClinicId = 1; // For example, assuming clinic with ID 1 is logged in

    const sampleData = [
      { id: 1, name: 'Downtown Medical Center', location: 'Kandy', type: 'Hospital', status: 'Active', contactEmail: 'downtown@medical.com', openTime: '08:00 AM', closeTime: '06:00 PM' },
      { id: 2, name: 'Westside Clinic', location: 'Ampara', type: 'Clinic', status: 'Active', contactEmail: 'west@clinic.com', openTime: '09:00 AM', closeTime: '05:00 PM' },
      { id: 3, name: 'Southgate Health Center', location: 'Colombo', type: 'Health Center', status: 'Inactive', contactEmail: 'south@health.com', openTime: '10:00 AM', closeTime: '04:00 PM' },
      { id: 4, name: 'Eastern Medical Facility', location: 'Galle', type: 'Hospital', status: 'Active', contactEmail: 'eastern@medical.com', openTime: '07:00 AM', closeTime: '07:00 PM' }
    ];

    const loggedInClinic = sampleData.find(center => center.id === loggedInClinicId);
    setCenters(sampleData); // Set all centers (for demonstration)
    setCurrentClinic(loggedInClinic); // Set the logged-in clinic center data
  }, []);

  const handleDelete = (id) => {
    setCenters(centers.filter(center => center.id !== id));
  };

  const handleUpdate = (id) => {
    alert(`Update center with ID: ${id}`);
  };

  const handleGenerateReport = (date) => {
    alert(`Generate report for date: ${date}`);
  };

  return (
    <div style={styles.container}>
      {/* Display only the logged-in clinic center */}
      {currentClinic ? (
        <>
          <h1 style={styles.title}>Welcome to {currentClinic.name} Dashboard</h1>
          <div style={styles.dashboardContainer}>
            <div style={styles.dashboardCard}>
              <div style={styles.cardIcon}>👨‍⚕️</div>
              <h2 style={styles.cardTitle}>Manage Doctor Availability</h2>
              <p style={styles.cardSubtitle}>Manage availability for doctors at {currentClinic.name}.</p>
              <a href={`/centers/doctor-availability/${currentClinic.id}`} style={styles.cardLink}>View Availability →</a>
            </div>

            <div style={styles.dashboardCard}>
              <div style={styles.cardIcon}>👥</div>
              <h2 style={styles.cardTitle}>Manage Staff</h2>
              <p style={styles.cardSubtitle}>Manage medical staff and administrators at {currentClinic.name}.</p>
              <a href={`/centers/staff/${currentClinic.id}`} style={styles.cardLink}>View Staff →</a>
            </div>

            <div style={styles.dashboardCard}>
              <div style={styles.cardIcon}>📊</div>
              <h2 style={styles.cardTitle}>Analytics</h2>
              <p style={styles.cardSubtitle}>View performance metrics and reports for {currentClinic.name}.</p>
              <a href={`/centers/analytics/${currentClinic.id}`} style={styles.cardLink}>View Reports →</a>
            </div>

            <div style={styles.dashboardCard}>
              <div style={styles.cardIcon}>⚙️</div>
              <h2 style={styles.cardTitle}>System Settings</h2>
              <p style={styles.cardSubtitle}>Configure system parameters for {currentClinic.name}.</p>
              <a href={`/centers/settings/${currentClinic.id}`} style={styles.cardLink}>View Settings →</a>
            </div>
          </div>
        </>
      ) : (
        <p>Loading Clinic Dashboard...</p>
      )}

      {/* Centers Table */}
      <h1 style={styles.title}>Clinical Centers</h1>
      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead style={styles.tableHeader}>
            <tr>
              <th>#</th>
              <th>Center Name</th>
              <th>Location</th>
              <th>Type</th>
              <th>Status</th>
              <th>Contact Email</th>
              <th>Open Time</th>
              <th>Close Time</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {centers.map((center, index) => (
              <tr key={center.id} style={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
                <td>{index + 1}</td>
                <td>{center.name}</td>
                <td>{center.location}</td>
                <td>{center.type}</td>
                <td>
                  <span style={{
                    padding: '6px 12px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    backgroundColor: center.status === 'Active' ? '#d4edda' : '#f8d7da',
                    color: center.status === 'Active' ? '#155724' : '#721c24'
                  }}>
                    {center.status}
                  </span>
                </td>
                <td>{center.contactEmail}</td>
                <td>{center.openTime}</td>
                <td>{center.closeTime}</td>
                <td>
                  <button style={styles.editButton} onClick={() => handleUpdate(center.id)}>Edit</button>
                  <button style={styles.deleteButton} onClick={() => handleDelete(center.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </div>
  );
};

// Enhanced Styles for Clinical Center Dashboard
const styles = {
  container: {
    backgroundColor: '#f8f9fa',
    minHeight: '100vh',
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  dashboardContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: '30px',
    width: '100%',
    maxWidth: '1300px',
    marginBottom: '50px',
  },
  dashboardCard: {
    backgroundColor: '#ffffff',
    borderRadius: '10px',
    padding: '30px',
    width: '280px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    transition: 'transform 0.3s ease',
    cursor: 'pointer',
  },
  cardIcon: {
    fontSize: '32px',
    marginBottom: '20px',
  },
  cardTitle: {
    fontSize: '1.4rem',
    fontWeight: '700',
    color: '#333333',
    margin: '0 0 10px 0',
  },
  cardSubtitle: {
    fontSize: '1rem',
    color: '#6c757d',
    margin: '0 0 20px 0',
  },
  cardLink: {
    color: '#007bff',
    textDecoration: 'none',
    fontSize: '1rem',
    marginTop: 'auto',
  },
  title: {
    fontSize: '2rem',
    marginBottom: '20px',
    color: '#333333',
    width: '100%',
    maxWidth: '1300px',
    textAlign: 'left',
    marginLeft: '40px',
  },
  tableContainer: {
    width: '100%',
    maxWidth: '1300px',
    overflowX: 'auto',
    backgroundColor: '#ffffff',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    padding: '30px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    color: '#333333',
    fontSize: '1rem',
  },
  tableHeader: {
    backgroundColor: '#f4f4f4',
    textAlign: 'left',
    padding: '20px',
    color: '#333333',
  },
  evenRow: {
    backgroundColor: '#f9f9f9',
    color: '#333333',
  },
  oddRow: {
    backgroundColor: '#ffffff',
    color: '#333333',
  },
  editButton: {
    padding: '8px 14px',
    margin: '5px',
    border: 'none',
    backgroundColor: '#28a745',
    color: 'white',
    cursor: 'pointer',
    borderRadius: '6px',
    fontSize: '16px',
  },
  deleteButton: {
    padding: '8px 14px',
    margin: '5px',
    border: 'none',
    backgroundColor: '#dc3545',
    color: 'white',
    cursor: 'pointer',
    borderRadius: '6px',
    fontSize: '16px',
  },
  dateInput: {
    padding: '8px 14px',
    margin: '20px 0',
    border: '1px solid #ccc',
    borderRadius: '6px',
  }
};

export default ClinicalCenterDashboard;
