'use client';  // Mark the component as client-side

import React, { useState } from 'react';

// New Clinic Sender Component
const NewClinicSender = () => {
  const [clinicDetails, setClinicDetails] = useState({
    clinicName: '',
    city: '',
    availabilityTime: '',
    contactNumber: '',
    email: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setClinicDetails({ ...clinicDetails, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('New Clinic Sender details saved!');
    console.log(clinicDetails);
  };

  const handleCancel = () => {
    setClinicDetails({
      clinicName: '',
      city: '',
      availabilityTime: '',
      contactNumber: '',
      email: '',
    });
  };

  return (
    <div style={formStyles.container}>
      <h1 style={formStyles.title}>New Clinic Sender</h1>

      <div style={formStyles.formAndImageContainer}>
        <div style={formStyles.formContainer}>
          <form onSubmit={handleSubmit}>
            <div style={formStyles.section}>
              <label style={formStyles.label}>Clinic Name:</label>
              <input
                type="text"
                name="clinicName"
                value={clinicDetails.clinicName}
                onChange={handleInputChange}
                style={formStyles.input}
                required
              />
            </div>

            <div style={formStyles.section}>
              <label style={formStyles.label}>City:</label>
              <input
                type="text"
                name="city"
                value={clinicDetails.city}
                onChange={handleInputChange}
                style={formStyles.input}
                required
              />
            </div>

            <div style={formStyles.section}>
              <label style={formStyles.label}>Availability Time:</label>
              <input
                type="text"
                name="availabilityTime"
                value={clinicDetails.availabilityTime}
                onChange={handleInputChange}
                style={formStyles.input}
                required
              />
            </div>

            <div style={formStyles.section}>
              <label style={formStyles.label}>Contact Number:</label>
              <input
                type="text"
                name="contactNumber"
                value={clinicDetails.contactNumber}
                onChange={handleInputChange}
                style={formStyles.input}
                required
              />
            </div>

            <div style={formStyles.section}>
              <label style={formStyles.label}>Email Address:</label>
              <input
                type="email"
                name="email"
                value={clinicDetails.email}
                onChange={handleInputChange}
                style={formStyles.input}
                required
              />
            </div>

            <div style={formStyles.actionButtons}>
              <button type="submit" style={formStyles.saveButton}>Save</button>
              <button type="button" onClick={handleCancel} style={formStyles.cancelButton}>Cancel</button>
            </div>
          </form>
        </div>

        {/* Image of Clinic Management */}
        <div style={formStyles.imageContainer}>
          <img src="/images/clinic-management.jpg" alt="Clinic Management" style={formStyles.image} />
        </div>
      </div>
    </div>
  );
};

// Styles for the New Clinic Sender Form
const formStyles = {
  container: {
    backgroundColor: '#ffffff',
    minHeight: '100vh',
    padding: '20px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  title: {
    fontSize: '2.2rem',
    marginBottom: '20px',
    color: '#222222',
    fontWeight: '700',
  },
  formAndImageContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    width: '100%',
    maxWidth: '1200px',
  },
  formContainer: {
    width: '50%',
    padding: '20px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
    borderRadius: '8px',
    backgroundColor: '#f9f9f9',
  },
  section: {
    marginBottom: '15px',
  },
  label: {
    display: 'block',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '5px',
  },
  input: {
    width: '100%',
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    fontSize: '1rem',
  },
  actionButtons: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: '20px',
  },
  saveButton: {
    padding: '10px 20px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  cancelButton: {
    padding: '10px 20px',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
  },
  imageContainer: {
    width: '50%',
    padding: '20px',
    display: 'flex',
    justifyContent: 'center',
  },
  image: {
    width: '100%',
    maxWidth: '500px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
  },
};

export default NewClinicSender;
