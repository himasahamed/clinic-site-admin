'use client';

import { useState } from "react";
import Link from "next/link";
import { FaHome, FaUserMd, FaUsers, FaUser, FaFileAlt, FaSearch, FaBuilding, FaClock, FaCogs, FaQuestionCircle } from 'react-icons/fa'; // Correct import

export default function AdminDashboard() {
  const [appointments, setAppointments] = useState([
    { patient: "John Doe", doctor: "Dr. Smith", center: "Central Clinic", status: "Completed", date: "2025-03-10" },
    { patient: "Jane Smith", doctor: "Dr. Johnson", center: "North Clinic", status: "Ongoing", date: "2025-03-15" },
    { patient: "Robert Brown", doctor: "Dr. Davis", center: "East Clinic", status: "New", date: "2025-03-20" },
    { patient: "Emily Wilson", doctor: "Dr. Garcia", center: "South Clinic", status: "Cancelled", date: "2025-03-22" },
  ]);

  return (
    <div className="bg-white min-h-screen flex flex-row">

      {/* Main Content Section */}
      <div className="flex-1 p-8">
        {/* Dashboard Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {/* Manage Users */}
          <div className="bg-white rounded-xl shadow-lg p-4 text-center">
            <div className="text-3xl text-indigo-600 mb-3">
              <FaUsers />
            </div>
            <h2 className="font-semibold text-xl text-gray-800">Manage Users</h2>
            <p className="text-gray-500 mt-2">
              Total Users: <span className="font-bold">50</span>
            </p>
            <Link href="/admin/manage-users" className="mt-3 text-indigo-600">View Users →</Link>
          </div>

          {/* Manage Doctors */}
          <div className="bg-white rounded-xl shadow-lg p-4 text-center">
            <div className="text-3xl text-green-600 mb-3">
              <FaUserMd />
            </div>
            <h2 className="font-semibold text-xl text-gray-800">Manage Doctors</h2>
            <p className="text-gray-500 mt-2">
              Total Doctors: <span className="font-bold">10</span>
            </p>
            <Link href="/admin/manage-doctors" className="mt-3 text-green-600">View Doctors →</Link>
          </div>

          {/* Appointments */}
          <div className="bg-white rounded-xl shadow-lg p-4 text-center">
            <div className="text-3xl text-orange-600 mb-3">
              <FaFileAlt />
            </div>
            <h2 className="font-semibold text-xl text-gray-800">Appointments</h2>
            <p className="text-gray-500 mt-2">
              Total Appointments: <span className="font-bold">30</span>
            </p>
            <Link href="/admin/appointment-history" className="mt-3 text-orange-600">View Appointments →</Link>
          </div>
        </div>

        {/* Additional Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {/* Manage Clinical Center */}
          <div className="bg-white rounded-xl shadow-lg p-4 text-center">
            <div className="text-3xl text-blue-600 mb-3">
              <FaBuilding />
            </div>
            <h2 className="font-semibold text-xl text-gray-800">Manage Clinical Center</h2>
            <p className="text-gray-500 mt-2">
              Manage your clinical centers and DICs.
            </p>
            <Link href="/admin/manage-clinical-centers" className="mt-3 text-blue-600">View Centers →</Link>
          </div>

          {/* Manage New Queries */}
          <div className="bg-white rounded-xl shadow-lg p-4 text-center">
            <div className="text-3xl text-red-600 mb-3">
              <FaQuestionCircle />
            </div>
            <h2 className="font-semibold text-xl text-gray-800">Manage New Queries</h2>
            <p className="text-gray-500 mt-2">
              Handle incoming queries and issues.
            </p>
            <Link href="/admin/manage-queries" className="mt-3 text-red-600">View Queries →</Link>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-lg mb-6">
          <div className="px-6 py-4 border-b">
            <h3 className="text-xl font-semibold text-gray-800">Quick Actions</h3>
          </div>
          <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Add Clinic */}
            <Link href="/admin/clinical-centers/new" className="p-4 bg-gray-700 hover:bg-gray-800 text-white rounded-lg flex items-center gap-3 transition-colors duration-200 ease-in-out">
              <div className="p-2 bg-indigo-600 rounded-lg">
                <i className="fa fa-hospital-alt text-white"></i>
              </div>
              <span>Add New Clinic</span>
            </Link>

            {/* Add Doctor */}
            <Link href="/admin/doctors/new" className="p-4 bg-[#72BF78] hover:bg-[#5e9f60] text-white rounded-lg flex items-center gap-3 transition-colors duration-200 ease-in-out">
              <div className="p-2 bg-[#72BF78] rounded-lg">
                <i className="fa fa-user-md text-white"></i>
              </div>
              <span>Add New Doctor</span>
            </Link>

            {/* Generate Report */}
            <Link href="/admin/reports/generate" className="p-4 bg-blue-700 hover:bg-blue-800 text-white rounded-lg flex items-center gap-3 transition-colors duration-200 ease-in-out">
              <div className="p-2 bg-blue-600 rounded-lg">
                <i className="fa fa-file-alt text-white"></i>
              </div>
              <span>Generate Report</span>
            </Link>
          </div>
        </div>

        {/* Recent Appointments Table */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="px-6 py-4 border-b">
            <h3 className="text-xl font-semibold text-gray-800">Recent Appointments</h3>
          </div>
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="text-left text-gray-500 uppercase text-xs">
                    <th className="px-6 py-3">Patient</th>
                    <th className="px-6 py-3">Doctor</th>
                    <th className="px-6 py-3">Center</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {appointments.map((appointment, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 text-gray-800">{appointment.patient}</td>
                      <td className="px-6 py-4 text-gray-800">{appointment.doctor}</td>
                      <td className="px-6 py-4 text-gray-800">{appointment.center}</td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-2 py-1 text-xs rounded-full ${appointment.status === 'Completed' ? 'bg-green-100 text-green-800' : appointment.status === 'Ongoing' ? 'bg-yellow-100 text-yellow-800' : appointment.status === 'Cancelled' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}`}
                        >
                          {appointment.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 text-right">
              <Link href="/admin/appointments" className="text-indigo-600 hover:text-indigo-900 text-sm font-medium">
                View all appointments → 
              </Link>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
