'use client';

import React, { useState, useEffect } from 'react';
import Header from '../components/Header';

const ClinicalCenterDashboard = () => {
  const [centers, setCenters] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const sampleData = [
        { id: 1, name: 'Downtown Medical Center', location: 'Colombo', type: 'Clinic', status: 'Active', contactEmail: 'downtown@medical.com', openTime: '08:00 AM', closeTime: '06:00 PM' },
        { id: 2, name: 'Westside Clinic', location: 'Kandy', type: 'Clinic', status: 'Active', contactEmail: 'west@clinic.com', openTime: '09:00 AM', closeTime: '05:00 PM' },
        { id: 3, name: 'Eastern Medical Facility', location: 'Jaffna', type: 'Clinic', status: 'Active', contactEmail: 'eastern@medical.com', openTime: '07:00 AM', closeTime: '07:00 PM' }
      ];

      // Filter to only include clinics
      const clinicCenters = sampleData.filter(center => center.type === 'Clinic');
      setCenters(clinicCenters);
    };

    fetchData();
  }, []);

  const handleDelete = (id) => {
    setCenters(centers.filter(center => center.id !== id));
  };

  const handleUpdate = (id) => {
    alert(`Update center with ID: ${id}`);
  };

  return (
    <div style={styles.container}>
      <Header />
      
      {/* Centers Table */}
      <h1 style={styles.title}>Clinical Centers</h1>
      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead style={styles.tableHeader}>
            <tr>
              <th>#</th>
              <th>Center Name</th>
              <th>Location</th>
              <th>Type</th>
              <th>Status</th>
              <th>Contact Email</th>
              <th>Open Time</th>
              <th>Close Time</th>
            </tr>
          </thead>
          <tbody>
            {centers.map((center, index) => (
              <tr key={center.id} style={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
                <td style={styles.tableCell}>{index + 1}</td>
                <td style={styles.tableCell}>{center.name}</td>
                <td style={styles.tableCell}>{center.location}</td>
                <td style={styles.tableCell}>{center.type}</td>
                <td style={styles.tableCell}>
                  <span style={{
                    padding: '6px 12px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    backgroundColor: center.status === 'Active' ? '#d4edda' : '#f8d7da',
                    color: center.status === 'Active' ? '#155724' : '#721c24'
                  }}>
                    {center.status}
                  </span>
                </td>
                <td style={styles.tableCell}>{center.contactEmail}</td>
                <td style={styles.tableCell}>{center.openTime}</td>
                <td style={styles.tableCell}>{center.closeTime}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Enhanced Styles for Clinical Center Dashboard
const styles = {
  container: {
    backgroundColor: '#f8f9fa',
    minHeight: '100vh',
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    paddingTop: '20px',
  },
  title: {
    fontSize: '2rem',
    marginBottom: '30px',
    color: '#333333',
    width: '100%',
    maxWidth: '1300px',
    textAlign: 'left',
    marginLeft: '40px',
  },
  tableContainer: {
    width: '100%',
    maxWidth: '1300px',
    overflowX: 'auto',
    backgroundColor: '#ffffff',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    padding: '30px',
    marginBottom: '40px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    color: '#333333',
    fontSize: '1rem',
    textAlign: 'center',
  },
  tableHeader: {
    backgroundColor: '#f4f4f4',
    textAlign: 'center',
    padding: '15px',
    color: '#333333',
    fontWeight: 'bold',
  },
  tableCell: {
    padding: '12px 20px',
    textAlign: 'center',
    border: '1px solid #ddd',
  },
  evenRow: {
    backgroundColor: '#f9f9f9',
    color: '#333333',
  },
  oddRow: {
    backgroundColor: '#ffffff',
    color: '#333333',
  },
};

export default ClinicalCenterDashboard;
