'use client';

import React, { useState, useEffect } from 'react';
import Header from '../components/Header';

const ClinicalCenterDashboard = () => {
  const [centers, setCenters] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const sampleData = [
        { id: 1, name: 'Downtown Medical Center', location: 'New York', type: 'Hospital', status: 'Active', contactEmail: 'downtown@medical.com', openTime: '08:00 AM', closeTime: '06:00 PM' },
        { id: 2, name: 'Westside Clinic', location: 'Chicago', type: 'Clinic', status: 'Active', contactEmail: 'west@clinic.com', openTime: '09:00 AM', closeTime: '05:00 PM' },
        { id: 3, name: 'Southgate Health Center', location: 'Miami', type: 'Health Center', status: 'Inactive', contactEmail: 'south@health.com', openTime: '10:00 AM', closeTime: '04:00 PM' },
        { id: 4, name: 'Eastern Medical Facility', location: 'Boston', type: 'Hospital', status: 'Active', contactEmail: 'eastern@medical.com', openTime: '07:00 AM', closeTime: '07:00 PM' }
      ];

      setCenters(sampleData);
    };

    fetchData();
  }, []);

  const handleDelete = (id) => {
    setCenters(centers.filter(center => center.id !== id));
  };

  const handleUpdate = (id) => {
    alert(`Update center with ID: ${id}`);
  };

  return (
    <div style={styles.container}>
      <Header />
      
      {/* Dashboard cards section */}
      <div style={styles.dashboardContainer}>
        <div style={styles.dashboardCard}>
          <div style={styles.cardIcon}>🏥</div>
          <h2 style={styles.cardTitle}>Manage Clinical Center</h2>
          <p style={styles.cardSubtitle}>Manage your clinical centers and DICs.</p>
          <a href="/centers" style={styles.cardLink}>View Centers →</a>
        </div>
        
        <div style={styles.dashboardCard}>
          <div style={styles.cardIcon}>👥</div>
          <h2 style={styles.cardTitle}>Manage Staff</h2>
          <p style={styles.cardSubtitle}>Manage medical staff and administrators.</p>
          <a href="/staff" style={styles.cardLink}>View Staff →</a>
        </div>
        
        <div style={styles.dashboardCard}>
          <div style={styles.cardIcon}>📊</div>
          <h2 style={styles.cardTitle}>Analytics</h2>
          <p style={styles.cardSubtitle}>View performance metrics and reports.</p>
          <a href="/analytics" style={styles.cardLink}>View Reports →</a>
        </div>
        
        <div style={styles.dashboardCard}>
          <div style={styles.cardIcon}>⚙️</div>
          <h2 style={styles.cardTitle}>System Settings</h2>
          <p style={styles.cardSubtitle}>Configure system parameters and access.</p>
          <a href="/settings" style={styles.cardLink}>View Settings →</a>
        </div>
      </div>
      
      {/* Centers Table */}
      <h1 style={styles.title}>Clinical Centers</h1>
      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead style={styles.tableHeader}>
            <tr>
              <th>#</th>
              <th>Center Name</th>
              <th>Location</th>
              <th>Type</th>
              <th>Status</th>
              <th>Contact Email</th>
              <th>Open Time</th>
              <th>Close Time</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {centers.map((center, index) => (
              <tr key={center.id} style={index % 2 === 0 ? styles.evenRow : styles.oddRow}>
                <td>{index + 1}</td>
                <td>{center.name}</td>
                <td>{center.location}</td>
                <td>{center.type}</td>
                <td>
                  <span style={{
                    padding: '6px 12px',
                    borderRadius: '12px',
                    fontSize: '14px',
                    backgroundColor: center.status === 'Active' ? '#d4edda' : '#f8d7da',
                    color: center.status === 'Active' ? '#155724' : '#721c24'
                  }}>
                    {center.status}
                  </span>
                </td>
                <td>{center.contactEmail}</td>
                <td>{center.openTime}</td>
                <td>{center.closeTime}</td>
                <td>
                  <button style={styles.editButton} onClick={() => handleUpdate(center.id)}>Edit</button>
                  <button style={styles.deleteButton} onClick={() => handleDelete(center.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Enhanced Styles for Clinical Center Dashboard
const styles = {
  container: {
    backgroundColor: '#f8f9fa',
    minHeight: '100vh',
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  dashboardContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: '30px',
    width: '100%',
    maxWidth: '1300px',
    marginBottom: '50px',
  },
  dashboardCard: {
    backgroundColor: '#ffffff',
    borderRadius: '10px',
    padding: '30px',
    width: '280px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    transition: 'transform 0.3s ease',
    cursor: 'pointer',
  },
  cardIcon: {
    fontSize: '32px',
    marginBottom: '20px',
  },
  cardTitle: {
    fontSize: '1.4rem',
    fontWeight: '700',
    color: '#333333',
    margin: '0 0 10px 0',
  },
  cardSubtitle: {
    fontSize: '1rem',
    color: '#6c757d',
    margin: '0 0 20px 0',
  },
  cardLink: {
    color: '#007bff',
    textDecoration: 'none',
    fontSize: '1rem',
    marginTop: 'auto',
  },
  title: {
    fontSize: '2rem',
    marginBottom: '20px',
    color: '#333333',
    width: '100%',
    maxWidth: '1300px',
    textAlign: 'left',
    marginLeft: '40px',
  },
  tableContainer: {
    width: '100%',
    maxWidth: '1300px',
    overflowX: 'auto',
    backgroundColor: '#ffffff',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    padding: '30px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    color: '#333333',
    fontSize: '1rem',
  },
  tableHeader: {
    backgroundColor: '#f4f4f4',
    textAlign: 'left',
    padding: '20px',
    color: '#333333',
  },
  evenRow: {
    backgroundColor: '#f9f9f9',
    color: '#333333',
  },
  oddRow: {
    backgroundColor: '#ffffff',
    color: '#333333',
  },
  editButton: {
    padding: '8px 14px',
    margin: '5px',
    border: 'none',
    backgroundColor: '#28a745',
    color: 'white',
    cursor: 'pointer',
    borderRadius: '6px',
    fontSize: '16px',
  },
  deleteButton: {
    padding: '8px 14px',
    margin: '5px',
    border: 'none',
    backgroundColor: '#dc3545',
    color: 'white',
    cursor: 'pointer',
    borderRadius: '6px',
    fontSize: '16px',
  }
};

export default ClinicalCenterDashboard;
