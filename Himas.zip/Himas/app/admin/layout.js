// app/admin/layout.js
import { ReactNode } from 'react';
import { FaHome, FaUserMd, FaUsers, FaUser, FaFileAlt, FaSearch, FaBuilding, FaClock, FaCogs, FaQuestionCircle } from 'react-icons/fa';
import Link from 'next/link';

export default function AdminLayout({ children }) {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar Section */}
      <aside className="w-80 bg-white p-6 shadow-md">
        <div className="flex flex-col space-y-4">
          {/* Logo and Sidebar Title */}
          <div className="flex items-center space-x-2 mb-8">
            <div className="text-2xl font-bold text-gray-800">MYO</div>
            <div className="text-lg text-gray-800">CLINIC</div>
          </div>

          {/* Main Navigation */}
          <div className="mt-8 space-y-8"> {/* Increased space between title and first nav item */}
            <h3 className="text-lg font-semibold text-black">MAIN NAVIGATION</h3>
            <ul className="space-y-6"> {/* Increased space between items */}
              <li>
                <Link href="/admin/dashboard" className="flex items-center text-black hover:text-blue-800 relative group">
                  <FaHome className="mr-2" />
                  Dashboard
                  <div className="absolute bottom-0 left-0 w-full h-[2px] bg-blue-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                </Link>
              </li>
              <li>
                <Link href="/admin/manage-doctors" className="flex items-center text-black hover:text-blue-800 relative group">
                  <FaUserMd className="mr-2" />
                  Doctors
                  <div className="absolute bottom-0 left-0 w-full h-[2px] bg-blue-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                </Link>
              </li>
              <li>
                <Link href="/admin/manage-users" className="flex items-center text-black hover:text-blue-800 relative group">
                  <FaUsers className="mr-2" />
                  Users
                  <div className="absolute bottom-0 left-0 w-full h-[2px] bg-blue-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                </Link>
              </li>

              <li>
                <Link href="/admin/appointment-history" className="flex items-center text-black hover:text-blue-800 relative group">
                  <FaFileAlt className="mr-2" />
                  Appointment History
                  <div className="absolute bottom-0 left-0 w-full h-[2px] bg-blue-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                </Link>
              </li>

              <li>
                <Link href="/admin/manage-clinical-centers" className="flex items-center text-black hover:text-blue-800 relative group">
                  <FaBuilding className="mr-2" />
                  Manage Clinical Centre & DIC
                  <div className="absolute bottom-0 left-0 w-full h-[2px] bg-blue-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                </Link>
              </li>

              <li>
                <Link href="/admin/manage-queries" className="flex items-center text-black hover:text-blue-800 relative group">
                  <FaQuestionCircle className="mr-2" />
                  Manage New Queries
                  <div className="absolute bottom-0 left-0 w-full h-[2px] bg-blue-800 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </aside>

      {/* Main Content Section */}
      <div className="flex-1 p-0.5">
        {children}
      </div>
    </div>
  );
}
